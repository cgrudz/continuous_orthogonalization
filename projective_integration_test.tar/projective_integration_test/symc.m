function M = symc(F)

M = 0.5 * ( F + F' );
